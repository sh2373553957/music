from django.shortcuts import render,redirect
from django.core.paginator import *
from django.http import Http404
from index.models import *
import time

def commentView(request,song_id):
    #搜索歌曲
    search_song = Dynamic.objects.select_related('song').order_by('-dynamic_search').all()[:6]
    #点评处理
    if request.method == 'POST':
        comment_text = request.POST.get('comment','')#获取点评内容,然后获取当前用户名，如果当亲用户没有登录网站
        comment_user = request.user.username if request.user.username else '匿名用户'
        if comment_text:
            comment = Comment()
            comment.comment_text = comment_text#点评内容
            comment.comment_user = comment_user#用户名
            comment.comment_date = time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(time.time()))#点评日期
            comment.song_id = song_id #song_id为Comment表关联的外键
            comment.save()
        return redirect('/comment/%s.html'%(str(song_id)))
    else:
        song_info = Song.objects.filter(song_id=song_id).first()
        #歌曲不存在，跑出404异常
        if not song_info:
            raise Http404
        comment_all = Comment.objects.filter(song_id=song_id).order_by('comment_date')

        song_name = song_info.song_name
        page = int(request.GET.get('page',1))#page代表点评信息的分页页数，page不存在，默认页数为1，存在，将参数值转为int型
        paginator = Paginator(comment_all,2)
        try:
            contacts = paginator.page(page)
        except PageNotAnInteger:
            contacts = paginator.page(1)
        except EmptyPage:
            contacts = paginator.page(paginator.num_pages)
        return render(request,'comment.html',locals())








