from django.shortcuts import render

from .models import *

#首页
def indexView(request):

    #热搜歌曲，Dynamic连接Song表查询
    hot_search_song = Dynamic.objects.select_related('song').order_by('-dynamic_search').all()[:9]#根据搜索次数将序排列
    #音乐分类，左侧导航
    label_list = Label.objects.all()
    #热门歌曲右侧导航
    hot_play = Dynamic.objects.select_related('song').order_by('-dynamic_plays').all()[:10]
    #新歌推荐
    new_song_recommendation = Song.objects.order_by('song_release').all()[:9]
    #热门搜索，热门下载
    search_ranking = hot_search_song[:9]
    down_ranking = Dynamic.objects.select_related('song').order_by('-dynamic_down').all()[:6]
    all_ranking = [search_ranking,down_ranking]
    return render(request,'index.html',locals())



# 自定义404和500的错误页面
def page_not_found(request,exception=None):
    return render(request, 'error404.html', status=404)





