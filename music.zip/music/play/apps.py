from django.apps import AppConfig


class PlayConfig(AppConfig):
    name = 'play'
