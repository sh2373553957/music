from django.shortcuts import render,redirect
from django.core.paginator import  *
from django.db.models import *
from index.models import *

def searchView(request,page):

    if request.method == 'GET':
        #搜索歌曲
        search_song = Dynamic.objects.select_related('song').order_by('-dynamic_search').all()[:6]

        #获取搜索内容，如果kword为空就查询全部歌曲
        kword = request.session.get('kword','')
        if kword:#如果存在，以kword为查询条件，分别在歌曲信息表song的字段song_name,song_singer进行模糊查询
                #并将结果以歌曲发行时间进行排序

            song_info = Song.objects.values('song_id','song_name','song_singer','song_time').filter(Q(song_name__icontains=kword)|Q(song_singer=kword)).order_by('-song_release').all()#
        else:
            song_info = Song.objects.values('song_id','song_name','song_singer','song_time').order_by('-song_release').all()

        #分页
        paginator = Paginator(song_info,5)
        try:
            contacts = paginator.page(page)#括号里面page为自定义参数
        except PageNotAnInteger:
            contacts = paginator.page(1)
        except EmptyPage:
            contacts = paginator.page(paginator.num_pages)

        #添加歌曲搜索次数
        song_exist = Song.objects.filter(song_name=kword)
        if song_exist:
            song_id = song_exist[0].song_id
            dynamic_info = Dynamic.objects.filter(song_id=int(song_id)).first()

            #1.如果歌曲动态信息存在，就在原来基础上+1
            if dynamic_info:
                dynamic_info.dynamic_search +=1
                dynamic_info.save()

            #2.若动态信息不存在，就创建新的动态信息
            else:
                dynamic = Dynamic(dynamic_plays=0,dynamic_search=1,dynamic_down=0,song_id=song_id)
                dynamic.save()
            return render(request,'search.html',locals())
        else:
            #处理post请求，并重定向搜索页面
            request.session['kword'] = request.POST.get('kword','')


    return redirect('/search/1.html')

